

class Locators(object):

    CHECKBOX = "//input[@name='test_checkbox']"
    INPUT_TEXT = "//input[@id='test_input_text']"
    SPAN = "//span[@id='test_span']"
    SELECT = "//select[@id='test_select']"
    OPTION1 = "Option 1"
    OPTION3 = "Option 3"
    GOOGLE_LINK = "//a[@id='link_to_google']"
    PROTOTYPE_LINK = "//a[@id='test_Prototype_link']"
    JQUERY_LINK ="//a[@id='test_jQuery_link']"